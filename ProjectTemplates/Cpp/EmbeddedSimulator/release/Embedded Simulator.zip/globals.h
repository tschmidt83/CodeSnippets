#ifndef  __GLOBALS_H
#define __GLOBALS_H

#define APP_SCREEN_WIDTH  320
#define APP_SCREEN_HEIGHT 240
#define WINDOW_CLASSNAME  "EmbeddedSimulator"
#define WINDOW_WINDOWNAME "Embedded Simulator"

#endif // ! __GLOBALS_H
