#ifndef __SIMULATION_H
#define __SIMULATION_H

// Prototypes
void Simulation_Initialize(void);
void Simulation_ProcessTimer(void);
void Simulation_ProcessLoop(void);

#endif // !__SIMULATION_H
