#include "simulation.h"

void Simulation_Initialize()
{
}

void Simulation_ProcessLoop()
{
}

void Simulation_ProcessTimer()
{
}